// main.ts
import { Actor } from "apify";
import { chromium } from "playwright-core";

// ../../api/ownership.ts
async function ownershipVerified(host, token, password) {
  const ua = { "user-agent": "MarketCartCI-verify/0.2 (+https://marketcart-ci.pages.dev)" };
  const jar = /* @__PURE__ */ new Map();
  const eat = (res) => {
    for (const c of res.headers.getSetCookie()) {
      const kv = c.split(";")[0];
      const i = kv.indexOf("=");
      if (i > 0) jar.set(kv.slice(0, i), kv.slice(i + 1));
    }
  };
  const cookie = () => [...jar].map(([k, v]) => `${k}=${v}`).join("; ");
  let r = await fetch(`https://${host}/`, { redirect: "manual", headers: ua });
  eat(r);
  const loc = r.headers.get("location") ?? "";
  if (r.status >= 300 && r.status < 400 && /\/password(\?|$)/.test(loc)) {
    if (!password) return { ok: false, why: "store is password-protected: include its storefrontPassword" };
    const g = await fetch(`https://${host}/password`, { redirect: "manual", headers: { ...ua, cookie: cookie() } });
    eat(g);
    const form = await g.text();
    const token2 = form.match(/name="authenticity_token"[^>]*value="([^"]+)"/)?.[1] ?? form.match(/value="([^"]+)"[^>]*name="authenticity_token"/)?.[1] ?? "";
    const body = new URLSearchParams({ form_type: "storefront_password", utf8: "\u2713", authenticity_token: token2, password });
    const p = await fetch(`https://${host}/password`, { method: "POST", redirect: "manual", headers: { ...ua, "content-type": "application/x-www-form-urlencoded", cookie: cookie() }, body });
    eat(p);
    if (p.status === 429) return { ok: false, why: "store rate-limited the password form (HTTP 429); retry later" };
    r = await fetch(`https://${host}/`, { redirect: "manual", headers: { ...ua, cookie: cookie() } });
    if (r.status >= 300 && r.status < 400 && /\/password/.test(r.headers.get("location") ?? "")) return { ok: false, why: "storefront password rejected" };
  }
  if (r.status !== 200) return { ok: false, why: `home page HTTP ${r.status}` };
  const html = (await r.text()).slice(0, 3e5);
  const tags = [...html.matchAll(/<meta[^>]+name=["']marketcart-verification["'][^>]+content=["']([a-f0-9]{24})["']/gi)].map((m) => m[1]);
  if (tags.length === 0) return { ok: false, why: "verification meta tag not found on the home page" };
  return tags.includes(token) ? { ok: true, why: "verified" } : { ok: false, why: "verification token does not match" };
}

// ../../engine/pacing.ts
var DEFAULT_PACING = { minIntervalMs: 15e3, baseBackoffMs: 3e4, maxBackoffMs: 3e5, jitterRatio: 0.2 };
var realClock = { now: () => Date.now(), sleep: (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms))), random: Math.random };
function parseRetryAfter(value, now) {
  if (!value) return null;
  const v = value.trim();
  if (/^\d+$/.test(v)) return Number(v) * 1e3;
  const t = Date.parse(v);
  if (Number.isNaN(t)) return null;
  return Math.max(0, t - now);
}
function backoffMs(level, policy, random) {
  const raw = Math.min(policy.maxBackoffMs, policy.baseBackoffMs * 2 ** Math.max(0, level));
  const jitter = 1 + (random() * 2 - 1) * policy.jitterRatio;
  return Math.min(policy.maxBackoffMs, Math.round(raw * jitter));
}
var StorePacer = class {
  policy;
  clock;
  state = /* @__PURE__ */ new Map();
  constructor(policy = DEFAULT_PACING, clock = realClock, initial) {
    this.policy = policy;
    this.clock = clock;
    for (const [k, v] of Object.entries(initial ?? {})) this.state.set(k, { ...v });
  }
  snapshot() {
    return Object.fromEntries([...this.state].map(([k, v]) => [k, { ...v }]));
  }
  // How long a new cycle on `host` would wait right now.
  waitMs(host) {
    const s = this.state.get(host.toLowerCase());
    return s ? Math.max(0, s.nextAt - this.clock.now()) : 0;
  }
  // Reserves the next slot synchronously (so concurrent callers queue behind each other), then sleeps until it.
  // Returns null without sleeping when the slot would start after `deadlineAt`.
  async acquire(host, deadlineAt = Number.POSITIVE_INFINITY) {
    const key = host.toLowerCase();
    const now = this.clock.now();
    const s = this.state.get(key) ?? { nextAt: 0, level: 0 };
    const slot = Math.max(now, s.nextAt);
    if (slot > deadlineAt) return null;
    s.nextAt = slot + this.policy.minIntervalMs;
    this.state.set(key, s);
    if (slot > now) await this.clock.sleep(slot - now);
    return { waitedMs: slot - now, startedAt: slot };
  }
  // Feed back the outcome of a cycle. A 429 pushes the store's next slot out (Retry-After or backoff).
  record(host, outcome) {
    const key = host.toLowerCase();
    const now = this.clock.now();
    const s = this.state.get(key) ?? { nextAt: now, level: 0 };
    if (outcome.rateLimited) {
      const wait = outcome.retryAfterMs != null ? Math.min(this.policy.maxBackoffMs, outcome.retryAfterMs) : backoffMs(s.level, this.policy, this.clock.random);
      s.level += 1;
      s.nextAt = Math.max(s.nextAt, now + Math.max(wait, this.policy.minIntervalMs));
    } else {
      s.level = 0;
      s.nextAt = Math.max(s.nextAt, now + this.policy.minIntervalMs);
    }
    this.state.set(key, s);
    return s.nextAt - now;
  }
};

// ../../engine/money.ts
var EXPONENT = {
  BIF: 0,
  CLP: 0,
  DJF: 0,
  GNF: 0,
  ISK: 0,
  JPY: 0,
  KMF: 0,
  KRW: 0,
  PYG: 0,
  RWF: 0,
  UGX: 0,
  VND: 0,
  VUV: 0,
  XAF: 0,
  XOF: 0,
  XPF: 0,
  BHD: 3,
  IQD: 3,
  JOD: 3,
  KWD: 3,
  LYD: 3,
  OMR: 3,
  TND: 3
};
function minorExponent(currency) {
  return EXPONENT[currency.toUpperCase()] ?? 2;
}
function shopifyCentsToIsoMinor(value, currency) {
  const exp = minorExponent(currency);
  return Math.round(value * 10 ** exp / 100);
}
var SYMBOLS = [
  ["US$", ["USD"]],
  ["CA$", ["CAD"]],
  ["C$", ["CAD"]],
  ["A$", ["AUD"]],
  ["AU$", ["AUD"]],
  ["NZ$", ["NZD"]],
  ["HK$", ["HKD"]],
  ["S$", ["SGD"]],
  ["R$", ["BRL"]],
  ["MX$", ["MXN"]],
  ["\u20AC", ["EUR"]],
  ["\xA3", ["GBP"]],
  ["\xA5", ["JPY", "CNY"]],
  ["\uFFE5", ["JPY", "CNY"]],
  ["\u20A9", ["KRW"]],
  ["\u20B9", ["INR"]],
  ["\u20BA", ["TRY"]],
  ["\u20BD", ["RUB"]],
  ["\u20AA", ["ILS"]],
  ["\u20AB", ["VND"]],
  ["z\u0142", ["PLN"]],
  ["K\u010D", ["CZK"]],
  ["kr", ["SEK", "NOK", "DKK", "ISK"]],
  ["Fr.", ["CHF"]],
  ["CHF", ["CHF"]],
  ["$", ["USD", "CAD", "AUD", "NZD", "MXN", "SGD", "HKD", "CLP", "COP", "ARS"]]
];
var ISO_CODE = /\b([A-Z]{3})\b/g;
var KNOWN_ISO = /* @__PURE__ */ new Set(["USD", "EUR", "GBP", "JPY", "CNY", "CHF", "CAD", "AUD", "NZD", "SEK", "NOK", "DKK", "PLN", "CZK", "HUF", "KRW", "INR", "BRL", "MXN", "SGD", "HKD", "TRY", "ILS", "AED", "SAR", "ZAR", "KWD", "BHD", "VND", "CLP", "ISK", "RON", "BGN"]);
function currencyCandidates(text) {
  const found = /* @__PURE__ */ new Set();
  for (const m of text.matchAll(ISO_CODE)) {
    if (KNOWN_ISO.has(m[1])) found.add(m[1]);
  }
  let rest = text.replace(ISO_CODE, " ");
  for (const [sym, codes] of SYMBOLS) {
    if (rest.includes(sym)) {
      codes.forEach((c) => found.add(c));
      rest = rest.split(sym).join(" ");
    }
  }
  return [...found];
}
function parseMoney(text, expectedCurrency) {
  if (!text || !text.trim()) return { amountMinor: null, currencyCandidates: [], error: "empty price text" };
  const candidates = currencyCandidates(text);
  const numeric = text.match(/\d[\d.,'’   ]*\d|\d/);
  if (!numeric) return { amountMinor: null, currencyCandidates: candidates, error: "no digits" };
  const raw = numeric[0].replace(/[\s  ]+$/u, "");
  const exp = minorExponent(expectedCurrency);
  const sepRe = /[.,'’   ]/gu;
  const seps = [...raw.matchAll(sepRe)];
  let intPart = raw;
  let fracPart = "";
  if (seps.length > 0 && exp > 0) {
    const last = seps[seps.length - 1];
    const after = raw.slice((last.index ?? 0) + 1);
    const isDecimalChar = last[0] === "." || last[0] === ",";
    const sameAsEarlier = seps.slice(0, -1).some((s) => s[0] === last[0]);
    if (isDecimalChar && after.length === exp && !sameAsEarlier) {
      if (exp === 3 && seps.length === 1) {
        return { amountMinor: null, currencyCandidates: candidates, error: `ambiguous separator in "${raw}" for 3-decimal currency` };
      }
      intPart = raw.slice(0, last.index);
      fracPart = after;
    }
  }
  const intDigits = intPart.replace(sepRe, "");
  if (!/^\d+$/.test(intDigits)) return { amountMinor: null, currencyCandidates: candidates, error: `unparseable "${raw}"` };
  const groups = intPart.split(sepRe);
  if (groups.length > 1 && groups.slice(1).some((g) => g.length !== 3)) {
    return { amountMinor: null, currencyCandidates: candidates, error: `irregular digit grouping in "${raw}"` };
  }
  const frac = (fracPart + "0".repeat(exp)).slice(0, exp);
  const amountMinor = Number(intDigits) * 10 ** exp + (exp > 0 ? Number(frac) : 0);
  return { amountMinor, currencyCandidates: candidates };
}

// ../../engine/assert.ts
function totalMode(flag) {
  return flag === true ? "required" : flag === false ? "off" : "optional";
}
var INCONCLUSIVE_CHECKS = /* @__PURE__ */ new Set(["visible.price.readable", "visible.currency.indicator", "visible.total.readable", "visible.total.currency.indicator"]);
function verifyMarket(requested, observedCountry, observedCurrency) {
  const verified = observedCountry === requested.country && observedCurrency === requested.currency;
  return {
    verified,
    observedCountry,
    observedCurrency,
    evidence: `in-session window.Shopify.country=${observedCountry ?? "null"}, window.Shopify.currency.active=${observedCurrency ?? "null"}`
  };
}
function norm(s) {
  return s.normalize("NFKC").replace(/\s+/g, " ").trim().toLowerCase();
}
function matchVisible(stored, visible, used) {
  let idx = visible.findIndex((v, i) => !used.has(i) && v.variantId !== null && v.variantId === stored.variantId);
  if (idx >= 0) return idx;
  idx = visible.findIndex((v, i) => {
    if (used.has(i) || v.variantId !== null) return false;
    if (norm(v.title) !== norm(stored.productTitle)) return false;
    const opts = v.options.map(norm).join(" / ");
    return stored.variantTitle === "Default Title" ? opts === "" : opts === norm(stored.variantTitle);
  });
  return idx;
}
function classify(market, requestedLines, stored, visible, options) {
  const checks = [];
  const add = (name, ok, detail) => checks.push({ name, ok, detail });
  const currency = market.observedCurrency ?? "";
  const wanted = /* @__PURE__ */ new Map();
  for (const l of requestedLines) wanted.set(l.variantId, (wanted.get(l.variantId) ?? 0) + l.quantity);
  const storedQty = /* @__PURE__ */ new Map();
  for (const l of stored.lines) storedQty.set(l.variantId, (storedQty.get(l.variantId) ?? 0) + l.quantity);
  for (const [variantId, qty] of wanted) {
    const got = storedQty.get(variantId);
    if (got === void 0) {
      add("stored.variant", false, `requested variant ${variantId} not in stored cart (stored: ${[...storedQty.keys()].join(", ") || "none"})`);
    } else {
      add("stored.variant", true, `variant ${variantId} stored`);
      add("stored.quantity", got === qty, got === qty ? `variant ${variantId} qty ${got}` : `variant ${variantId}: requested qty ${qty}, stored qty ${got}`);
    }
  }
  for (const variantId of storedQty.keys()) {
    if (!wanted.has(variantId)) add("stored.unexpected", false, `unexpected stored variant ${variantId}`);
  }
  add("stored.currency", stored.currency === currency, `stored cart currency ${stored.currency}, verified market currency ${currency}`);
  add("visible.lineCount", visible.lines.length === stored.lines.length, `stored ${stored.lines.length} line(s), visible ${visible.lines.length} line(s) in ${visible.surface}`);
  const used = /* @__PURE__ */ new Set();
  let unreadablePrice = false;
  for (const s of stored.lines) {
    const i = matchVisible(s, visible.lines, used);
    if (i < 0) {
      add("visible.line", false, `stored line ${s.productTitle} (${s.variantTitle}, variant ${s.variantId}) not visible`);
      continue;
    }
    used.add(i);
    const v = visible.lines[i];
    const opts = v.options.map(norm).join(" / ");
    const expectOpts = s.variantTitle === "Default Title" ? "" : norm(s.variantTitle);
    add("visible.variant", opts === expectOpts, `variant ${s.variantId}: stored "${s.variantTitle}", visible "${v.options.join(" / ") || "(none)"}"`);
    add("visible.quantity", v.quantity === s.quantity, `variant ${s.variantId}: stored qty ${s.quantity}, visible qty ${v.quantity ?? "unreadable"}`);
    const parsed = parseMoney(v.priceText, currency);
    v.parsed = parsed;
    if (parsed.amountMinor === null) {
      unreadablePrice = true;
      add("visible.price.readable", false, `variant ${s.variantId}: visible price unreadable (${parsed.error ?? "unknown"}) text="${v.priceText ?? ""}"`);
      continue;
    }
    if (parsed.currencyCandidates.length === 0) {
      unreadablePrice = true;
      add("visible.currency.indicator", false, `variant ${s.variantId}: visible price "${v.priceText}" shows no currency indicator; currency cannot be verified`);
    } else {
      add("visible.currency", parsed.currencyCandidates.includes(currency), `variant ${s.variantId}: visible "${v.priceText}" indicates ${parsed.currencyCandidates.join("|")}, market ${currency}`);
    }
    add("visible.amount", parsed.amountMinor === s.finalLinePriceMinor, `variant ${s.variantId}: stored line ${s.finalLinePriceMinor} ${currency} minor, visible ${parsed.amountMinor}`);
  }
  if (options.badge) {
    const count = visible.badgeCount ?? 0;
    add("visible.badge", count === stored.itemCount, `stored item_count ${stored.itemCount}, badge ${visible.badgeCount === null ? "absent" : visible.badgeCount}`);
  }
  if (options.total !== "off") {
    const required = options.total === "required";
    if (!visible.totalText) {
      if (required) add("visible.total.readable", false, `total required but not shown in ${visible.surface}; parity of the total cannot be verified`);
      else add("visible.total.absent", true, `no total shown in ${visible.surface}; total not checked (optional)`);
    } else {
      const t = parseMoney(visible.totalText, currency);
      if (t.amountMinor === null) {
        add("visible.total.readable", false, `visible total unreadable (${t.error ?? "unknown"}) text="${visible.totalText}"`);
      } else {
        if (t.currencyCandidates.length === 0) {
          if (required) add("visible.total.currency.indicator", false, `visible total "${visible.totalText}" shows no currency indicator; total currency cannot be verified`);
          else add("visible.total.currency.unverified", true, `visible total "${visible.totalText}" shows no currency indicator; amount checked only (optional)`);
        } else {
          add("visible.total.currency", t.currencyCandidates.includes(currency), `visible total "${visible.totalText}" indicates ${t.currencyCandidates.join("|")}, market ${currency}`);
        }
        add("visible.total", t.amountMinor === stored.totalMinor, `stored total ${stored.totalMinor}, visible "${visible.totalText}" -> ${t.amountMinor}`);
      }
    }
  }
  const failed = checks.filter((c) => !c.ok);
  const regressions = failed.filter((c) => !INCONCLUSIVE_CHECKS.has(c.name));
  if (regressions.length > 0) return { status: "REGRESSION", reason: regressions.map((c) => c.detail).join("; "), checks };
  if (unreadablePrice || failed.length > 0) return { status: "UNSUPPORTED", reason: failed.map((c) => c.detail).join("; "), checks };
  return { status: "PASS", reason: `stored == visible across ${stored.lines.length} line(s), market ${market.observedCountry}/${currency} verified in-session`, checks };
}

// ../../engine/adapters/dawn.ts
var DAWN_FAMILY = /* @__PURE__ */ new Set([
  "dawn",
  "refresh",
  "sense",
  "craft",
  "studio",
  "taste",
  "origin",
  "crave",
  "ride",
  "colorblock",
  "publisher",
  "spotlight",
  "trade"
]);
function readPageContext() {
  const w = window;
  const title = document.title || "";
  const body = (document.body?.innerText || "").slice(0, 2e3).toLowerCase();
  const challenge = /just a moment|attention required|verify you are human|checking your browser/i.test(title) || !!document.querySelector('#challenge-form, #challenge-running, iframe[src*="challenges.cloudflare.com"], [data-hcaptcha-widget-id], .g-recaptcha') || body.includes("verify you are human");
  return {
    country: w.Shopify?.country ?? null,
    currency: w.Shopify?.currency?.active ?? null,
    themeSchema: w.Shopify?.theme?.schema_name ?? null,
    themeVersion: w.Shopify?.theme?.schema_version ?? null,
    hasProductForm: !!document.querySelector('product-form form, form[action$="/cart/add"]'),
    challenge,
    title,
    routesRoot: w.Shopify?.routes?.root || "/"
  };
}
async function readStoredCart() {
  const w = window;
  const root = w.Shopify?.routes?.root || "/";
  const r = await fetch(root + "cart.js", { headers: { Accept: "application/json" }, credentials: "same-origin", cache: "no-store" });
  let body = null;
  try {
    body = await r.json();
  } catch {
    body = null;
  }
  return { ok: r.ok, status: r.status, body };
}

// ../../engine/adapters/themes.ts
var HORIZON_FAMILY = /* @__PURE__ */ new Set(["horizon"]);
function adapterForSchema(schema) {
  const s = (schema ?? "").toLowerCase();
  if (DAWN_FAMILY.has(s)) return "dawn";
  if (HORIZON_FAMILY.has(s)) return "horizon";
  return null;
}
var ADAPTERS = {
  dawn: {
    declaresBadge: true,
    selectors: {
      variantInput: 'product-form input[name="id"]',
      quantityInput: 'input.quantity__input[name="quantity"]',
      addButton: 'product-form button[name="add"]',
      drawer: "cart-drawer",
      drawerTrigger: "#cart-icon-bubble"
    }
  },
  horizon: {
    declaresBadge: true,
    selectors: {
      variantInput: 'product-form-component input[name="id"]',
      quantityInput: 'input[name="quantity"]:not([name="updates[]"])',
      addButton: 'add-to-cart-component button[name="add"], product-form-component button[name="add"]',
      drawer: "theme-drawer#cart-drawer dialog",
      drawerTrigger: 'button[aria-controls="cart-drawer"], [data-testid="cart-drawer-trigger"]'
    }
  }
};
function drawerIsOpen(adapter) {
  if (adapter === "dawn") {
    const d = document.querySelector("cart-drawer");
    return !!d && (d.classList.contains("active") || d.hasAttribute("open"));
  }
  const dlg = document.querySelector("theme-drawer#cart-drawer dialog");
  const host = document.querySelector("theme-drawer#cart-drawer");
  return !!dlg && (dlg.open || dlg.hasAttribute("open") || !!host?.hasAttribute("open"));
}
function readVisibleCartAny(arg) {
  const { surface, adapter } = arg;
  const txt = (el) => el ? el.innerText.replace(/\s+/g, " ").trim() : null;
  const shown = (el) => {
    const r = el.getClientRects();
    const cs = getComputedStyle(el);
    return r.length > 0 && cs.visibility !== "hidden" && cs.display !== "none";
  };
  if (adapter === "dawn") {
    const root2 = surface === "drawer" ? document.querySelector("cart-drawer") : document.querySelector("cart-items, #main-cart-items, main");
    const drawerOpen2 = surface === "drawer" ? !!root2 && (root2.classList.contains("active") || root2.hasAttribute("open")) : true;
    const rows2 = root2 ? Array.from(root2.querySelectorAll(".cart-item")).filter(shown) : [];
    const lines2 = rows2.map((row) => {
      const link = row.querySelector("a.cart-item__name");
      const qty = row.querySelector("input.quantity__input");
      const price = row.querySelector(".cart-item__totals .price, .cart-item__price-wrapper .price, .cart-item__final-price");
      return { href: link ? link.getAttribute("href") : null, title: txt(link) ?? txt(row.querySelector(".cart-item__name")) ?? "", options: Array.from(row.querySelectorAll(".product-option dd")).map((d) => txt(d) ?? ""), quantity: qty ? qty.value : null, priceText: txt(price) };
    });
    const bubble2 = document.querySelector("#cart-icon-bubble .cart-count-bubble");
    const badgeText2 = bubble2 ? txt(bubble2.querySelector('span[aria-hidden="true"]')) ?? txt(bubble2) : null;
    const totalEl2 = root2 ? root2.querySelector(".totals__total-value") : null;
    return { surface, adapter, drawerOpen: drawerOpen2, lines: lines2, badgeText: badgeText2, totalText: totalEl2 && shown(totalEl2) ? txt(totalEl2) : null };
  }
  const drawerHost = document.querySelector("theme-drawer#cart-drawer");
  const dlg = drawerHost ? drawerHost.querySelector("dialog") : null;
  const root = surface === "drawer" ? dlg : document.querySelector("main cart-items-component, main .cart-items__table, main");
  const drawerOpen = surface === "drawer" ? !!dlg && (dlg.open || dlg.hasAttribute("open") || !!drawerHost?.hasAttribute("open")) : true;
  const rows = root ? Array.from(root.querySelectorAll("tr.cart-items__table-row:not(.cart-items__nested-line)")).filter((r) => !r.closest("template")) : [];
  const lines = rows.map((row) => {
    const link = row.querySelector("a.cart-items__title");
    const qty = row.querySelector('input[name="updates[]"], input[name="quantity"]');
    const price = row.querySelector("td.cart-items__price bdi, td.cart-items__price text-component, td.cart-items__price");
    const options = Array.from(row.querySelectorAll("dl.cart-items__variants dd")).map((d) => (txt(d) ?? "").replace(/[, \s]+$/u, "").trim());
    return { href: link ? link.getAttribute("href") : null, title: txt(link) ?? "", options, quantity: qty ? qty.value : null, priceText: txt(price) };
  });
  const bubble = document.querySelector('.cart-bubble__text-count, [data-testid="cart-bubble"]');
  const bubbleWrap = bubble ? bubble.closest(".cart-bubble") : null;
  const bubbleHidden = !bubble || bubble.classList.contains("hidden") || !!bubbleWrap?.classList.contains("visually-hidden");
  const badgeText = bubbleHidden ? null : txt(bubble);
  const totalEl = root ? root.querySelector('.cart-totals__total-value, [data-testid="cart-total-value"]') : null;
  return { surface, adapter, drawerOpen, lines, badgeText: badgeText === "" ? null : badgeText, totalText: totalEl && shown(totalEl) ? txt(totalEl) : null };
}

// ../../engine/safety.ts
var nodeResolver = async (host) => {
  const dns = await import("node:dns/promises");
  const addrs = await dns.lookup(host, { all: true, verbatim: true });
  return addrs.map((a) => a.address);
};
var resolver = nodeResolver;
function ipFamily(s) {
  if (/^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/.test(s)) return 4;
  if (s.includes(":") && /^[0-9a-f:.]+$/i.test(s) && (s.match(/::/g) ?? []).length <= 1) return 6;
  return 0;
}
var SafetyError = class extends Error {
};
var BLOCKED_PATHS = [/^\/checkouts?(\/|$)/i, /^\/cart\/checkout/i, /\/checkouts?\//i, /^\/account(\/|$)/i, /^\/payments?(\/|$)/i, /^\/admin(\/|$)/i, /^\/password(\/|$)/i];
function isBlockedPath(pathname) {
  return BLOCKED_PATHS.some((re) => re.test(pathname));
}
function ipv4ToInt(ip) {
  return ip.split(".").reduce((acc, o) => (acc << 8) + Number(o), 0) >>> 0;
}
var V4_PRIVATE = [
  ["0.0.0.0", 8],
  ["10.0.0.0", 8],
  ["100.64.0.0", 10],
  ["127.0.0.0", 8],
  ["169.254.0.0", 16],
  ["172.16.0.0", 12],
  ["192.0.0.0", 24],
  ["192.0.2.0", 24],
  ["192.168.0.0", 16],
  ["198.18.0.0", 15],
  ["198.51.100.0", 24],
  ["203.0.113.0", 24],
  ["224.0.0.0", 4],
  ["240.0.0.0", 4]
];
function isPrivateAddress(ip) {
  const fam = ipFamily(ip);
  if (fam === 4) {
    const n = ipv4ToInt(ip);
    return V4_PRIVATE.some(([base, bits]) => n >>> 32 - bits === ipv4ToInt(base) >>> 32 - bits);
  }
  if (fam === 6) {
    const s = ip.toLowerCase();
    if (s === "::" || s === "::1") return true;
    const mapped = s.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateAddress(mapped[1]);
    return /^(fc|fd|fe8|fe9|fea|feb|ff)/.test(s) || s.startsWith("64:ff9b:") || s.startsWith("2001:db8");
  }
  return true;
}
function isLoopbackHost(host) {
  return host === "localhost" || host === "127.0.0.1" || host === "[::1]" || host === "::1";
}
function hostAuthorized(host, policy) {
  const h = host.toLowerCase();
  return policy.authorizedDomains.some((d) => {
    const dom = d.toLowerCase();
    return h === dom || h.endsWith("." + dom);
  });
}
var dnsCache = /* @__PURE__ */ new Map();
async function resolvesPublic(host) {
  if (ipFamily(host)) return !isPrivateAddress(host);
  let p = dnsCache.get(host);
  if (!p) {
    p = resolver(host).then((addrs) => addrs.length > 0 && addrs.every((a) => !isPrivateAddress(a))).catch(() => false);
    dnsCache.set(host, p);
  }
  return p;
}
async function assertCaseUrl(raw, policy) {
  let url;
  try {
    url = new URL(raw);
  } catch {
    throw new SafetyError(`invalid URL`);
  }
  if (url.username || url.password) throw new SafetyError("credentials in URL are not allowed");
  const loopback = isLoopbackHost(url.hostname);
  if (loopback) {
    if (!policy.allowLoopbackFixture) throw new SafetyError("loopback targets are not allowed");
    if (url.protocol !== "http:" && url.protocol !== "https:") throw new SafetyError("unsupported scheme");
  } else {
    if (url.protocol !== "https:") throw new SafetyError("only https storefronts are allowed");
    if (!hostAuthorized(url.hostname, policy)) throw new SafetyError(`host ${url.hostname} is not an owner-authorized domain`);
    if (!await resolvesPublic(url.hostname)) throw new SafetyError(`host ${url.hostname} resolves to a private/unresolvable address`);
  }
  if (isBlockedPath(url.pathname)) throw new SafetyError("checkout/account/payment paths are never visited");
  return url;
}
async function allowRequest(raw, isNavigation, policy) {
  let url;
  try {
    url = new URL(raw);
  } catch {
    return { ok: false, why: "invalid url" };
  }
  if (url.protocol === "data:" || url.protocol === "blob:") return { ok: true };
  if (url.protocol !== "https:" && url.protocol !== "http:") return { ok: false, why: `scheme ${url.protocol}` };
  if (isBlockedPath(url.pathname) && hostAuthorized(url.hostname, policy)) return { ok: false, why: "blocked path" };
  if (isBlockedPath(url.pathname) && isLoopbackHost(url.hostname)) return { ok: false, why: "blocked path" };
  if (isLoopbackHost(url.hostname)) return policy.allowLoopbackFixture ? { ok: true } : { ok: false, why: "loopback" };
  if (isNavigation && !hostAuthorized(url.hostname, policy)) return { ok: false, why: `navigation to unauthorized host ${url.hostname}` };
  if (url.protocol !== "https:") return { ok: false, why: "plain http sub-resource" };
  if (!await resolvesPublic(url.hostname)) return { ok: false, why: "private address" };
  return { ok: true };
}
var KEEP_PARAMS = /* @__PURE__ */ new Set(["variant", "country", "preview_theme_id"]);
function sanitizeUrl(raw) {
  try {
    const u = new URL(raw);
    u.username = "";
    u.password = "";
    u.hash = "";
    for (const k of [...u.searchParams.keys()]) if (!KEEP_PARAMS.has(k)) u.searchParams.delete(k);
    if (isLoopbackHost(u.hostname)) u.host = "fixture.local";
    return u.toString();
  } catch {
    return "[invalid-url]";
  }
}

// ../../engine/runner.ts
var MAX_TIMEOUT_MS = 9e4;
var Stop = class extends Error {
  status;
  retryable;
  rateLimited;
  retryAfterMs;
  constructor(status, reason, retryable = false, rate) {
    super(reason);
    this.status = status;
    this.retryable = retryable;
    this.rateLimited = !!rate;
    this.retryAfterMs = rate?.retryAfterMs ?? null;
  }
};
function isAddPath(u) {
  try {
    return /\/cart\/add(\.js)?$/.test(new URL(u).pathname);
  } catch {
    return false;
  }
}
async function waitForQuiet(page, inflight, quietMs = 400, maxMs = 5e3) {
  const start = Date.now();
  let quietSince = Date.now();
  while (Date.now() - start < maxMs) {
    if (inflight.n > 0) quietSince = Date.now();
    else if (Date.now() - quietSince >= quietMs) return;
    await page.waitForTimeout(50);
  }
}
function normalizeStored(body) {
  const currency = String(body.currency ?? "");
  return {
    currency,
    itemCount: Number(body.item_count ?? 0),
    totalMinor: shopifyCentsToIsoMinor(Number(body.total_price ?? 0), currency),
    lines: (body.items ?? []).map((i) => ({
      variantId: Number(i.variant_id),
      productTitle: i.product_title,
      variantTitle: i.variant_title ?? "Default Title",
      quantity: Number(i.quantity),
      finalLinePriceMinor: shopifyCentsToIsoMinor(Number(i.final_line_price), currency)
    }))
  };
}
async function passPasswordGate(page, origin, password, gate) {
  gate.open = true;
  try {
    await page.goto(origin + "/password", { waitUntil: "domcontentloaded" });
    if (!new URL(page.url()).pathname.startsWith("/password")) return;
    const hasForm = await page.evaluate(() => !!document.querySelector('form[action$="/password"] input[name="password"]'));
    if (!hasForm) throw new Stop("UNSUPPORTED", "storefront password page has no password form");
    const left = page.waitForURL((u) => !u.pathname.startsWith("/password"), { timeout: 15e3, waitUntil: "domcontentloaded" }).catch(() => {
    });
    await page.evaluate((pw) => {
      const f = document.querySelector('form[action$="/password"]');
      f.querySelector('input[name="password"]').value = pw;
      setTimeout(() => f.submit(), 0);
    }, password);
    await left;
    if (new URL(page.url()).pathname.startsWith("/password")) throw new Stop("BLOCKED", "storefront password rejected");
  } finally {
    gate.open = false;
  }
}
async function attempt(browser2, spec, opts, timeoutMs) {
  const policy = { authorizedDomains: spec.authorizedDomains, allowLoopbackFixture: opts.allowLoopbackFixture };
  const context = await browser2.newContext({ viewport: { width: 1280, height: 900 }, serviceWorkers: "block", acceptDownloads: false });
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    context.close().catch(() => {
    });
  }, timeoutMs);
  const blocked = [];
  const gate = { open: false };
  let passwordWall = false;
  let theme = { schema: null, version: null, adapter: null, surface: null };
  let adapter = null;
  let market = null;
  let stored = null;
  let visible = null;
  const checks = [];
  let page = null;
  try {
    await context.route("**/*", async (route) => {
      const req = route.request();
      const u = new URL(req.url());
      const gatePath = u.pathname === "/password" || u.pathname.startsWith("/password/");
      if (gatePath && gate.open && hostAuthorized(u.hostname, policy)) return route.continue();
      const d = await allowRequest(req.url(), req.isNavigationRequest(), policy);
      if (!d.ok) {
        if (gatePath && req.isNavigationRequest()) passwordWall = true;
        blocked.push(`${d.why}`);
        return route.abort("blockedbyclient");
      }
      if (opts.inject && req.method() === "POST" && isAddPath(req.url())) {
        if (opts.inject.kind === "stale-drawer") {
          const resp = await route.fetch();
          const json = await resp.json();
          delete json.sections;
          return route.fulfill({ response: resp, json });
        }
        const body = req.postData() ?? "";
        const swapped = body.split(String(opts.inject.from)).join(String(opts.inject.to));
        if (swapped !== body) return route.continue({ postData: swapped });
      }
      return route.continue();
    });
    await context.routeWebSocket(/.*/, (ws) => ws.close());
    const password = opts.storefrontPasswords?.[new URL(spec.lines[0].url).hostname.toLowerCase()];
    page = await context.newPage();
    page.on("dialog", (d) => d.dismiss().catch(() => {
    }));
    const pending = /* @__PURE__ */ new Set();
    const inflight = {
      get n() {
        return pending.size;
      }
    };
    page.on("request", (r) => pending.add(r));
    page.on("response", (r) => pending.delete(r.request()));
    page.on("requestfinished", (r) => pending.delete(r));
    page.on("requestfailed", (r) => pending.delete(r));
    const gateHost = new URL(spec.lines[0].url).hostname.toLowerCase();
    const cachedGate = password ? opts.gateCookies?.get(gateHost) : void 0;
    if (password && cachedGate) {
      await context.addCookies(cachedGate);
    } else if (password) {
      const first = await assertCaseUrl(spec.lines[0].url, policy);
      await passPasswordGate(page, first.origin, password, gate);
      if (opts.gateCookies) {
        const digest = (await context.cookies()).filter((c) => c.name === "storefront_digest");
        if (digest.length) opts.gateCookies.set(gateHost, digest);
      }
    }
    for (let i = 0; i < spec.lines.length; i++) {
      const line = spec.lines[i];
      await assertCaseUrl(line.url, policy);
      const resp = await page.goto(line.url, { waitUntil: "domcontentloaded" });
      const landed = new URL(page.url());
      if (landed.pathname === "/password" || landed.pathname.startsWith("/password/")) {
        if (cachedGate) {
          opts.gateCookies?.delete(gateHost);
          throw new Stop("ERROR", "storefront password session expired", true);
        }
        passwordWall = true;
        throw new Stop("BLOCKED", "storefront is password-protected; supply its storefront password (never in URLs)");
      }
      if (!hostAuthorized(landed.hostname, policy)) throw new Stop("UNSUPPORTED", `navigation left the owner-authorized domain (landed on ${landed.hostname})`);
      const code = resp?.status() ?? 0;
      const ctx = await page.evaluate(readPageContext);
      if (i === 0) theme = { schema: ctx.themeSchema, version: ctx.themeVersion, adapter: adapterForSchema(ctx.themeSchema), surface: null };
      if (code === 429) throw new Stop("BLOCKED", `storefront rate limited (HTTP 429)`, false, { retryAfterMs: parseRetryAfter(resp?.headers()["retry-after"], Date.now()) });
      if (ctx.challenge) throw new Stop("BLOCKED", `storefront blocked automation (HTTP ${code}, challenge page)`);
      if (code >= 500) throw new Stop("ERROR", `product page HTTP ${code}`, true);
      if (code >= 400) throw new Stop("UNSUPPORTED", `product page HTTP ${code}`);
      if (i === 0) {
        market = verifyMarket(spec.market, ctx.country, ctx.currency);
        checks.push({ name: "market.verified", ok: market.verified, detail: `requested ${spec.market.country}/${spec.market.currency}; ${market.evidence}` });
        if (!market.verified) throw new Stop("UNSUPPORTED", `requested market ${spec.market.country}/${spec.market.currency} not verified in-session (observed ${ctx.country ?? "null"}/${ctx.currency ?? "null"})`);
        const pre = await page.evaluate(readStoredCart);
        if (pre.status === 429) throw new Stop("BLOCKED", "stored cart rate limited before add (HTTP 429)", false, { retryAfterMs: null });
        if (!pre.ok || !pre.body) throw new Stop("ERROR", `stored cart unreadable before add (HTTP ${pre.status})`, pre.status >= 500);
        if (Number(pre.body.item_count ?? 0) !== 0) throw new Stop("ERROR", "session not isolated: cart not empty before first add", true);
      }
      const adapterName = adapterForSchema(ctx.themeSchema);
      if (!adapterName || !ctx.hasProductForm) {
        throw new Stop("UNSUPPORTED", `no supported adapter: theme schema "${ctx.themeSchema ?? "unknown"}"${ctx.hasProductForm ? "" : ", no product form"}`);
      }
      adapter = adapterName;
      const sel2 = ADAPTERS[adapterName].selectors;
      const selected = await page.inputValue(sel2.variantInput).catch(() => null);
      const preselected = selected !== null && Number(selected) === line.variantId;
      checks.push({ name: "theme.variantSelection", ok: preselected, detail: `requested variant ${line.variantId}, product form selected ${selected ?? "none"}` });
      if (line.quantity !== 1) {
        const q = await page.$(sel2.quantityInput);
        if (!q) throw new Stop("UNSUPPORTED", "quantity input not found; cannot request quantity > 1");
        await q.fill(String(line.quantity));
      }
      const respP = page.waitForResponse((r) => isAddPath(r.url()) && r.request().method() === "POST", { timeout: 0 });
      await page.click(sel2.addButton);
      const addResp = await respP;
      const addCode = addResp.status();
      if (addCode === 429) throw new Stop("BLOCKED", "add-to-cart rate limited (HTTP 429)", false, { retryAfterMs: parseRetryAfter(addResp.headers()["retry-after"], Date.now()) });
      if (addCode >= 500) throw new Stop("ERROR", `add-to-cart HTTP ${addCode}`, true);
      if (addCode >= 400) throw new Stop("UNSUPPORTED", `store rejected add-to-cart (HTTP ${addCode}); variant unavailable?`);
      await waitForQuiet(page, inflight);
      await page.waitForTimeout(250);
    }
    const raw = await page.evaluate(readStoredCart);
    if (raw.status === 429) throw new Stop("BLOCKED", "stored cart rate limited (HTTP 429)", false, { retryAfterMs: null });
    if (!raw.ok || !raw.body) throw new Stop("ERROR", `stored cart unreadable (HTTP ${raw.status})`, raw.status >= 500);
    stored = normalizeStored(raw.body);
    const ad = adapter;
    const sel = ADAPTERS[ad].selectors;
    let surface = "drawer";
    if (await page.$(sel.drawer)) {
      const autoOpened = await page.evaluate(drawerIsOpen, ad);
      checks.push({ name: "surface.drawer.autoOpen", ok: true, detail: autoOpened ? "drawer opened after add" : "drawer stayed closed after add; opened from the header cart control" });
      if (!autoOpened) {
        await page.click(sel.drawerTrigger).catch(() => {
        });
        await page.waitForTimeout(500);
      }
    } else {
      surface = "cart-page";
      const root = await page.evaluate(readPageContext).then((c) => c.routesRoot);
      await page.goto(new URL(root + "cart", page.url()).toString(), { waitUntil: "domcontentloaded" });
    }
    theme.surface = surface;
    const rv = await page.evaluate(readVisibleCartAny, { surface, adapter: ad });
    if (surface === "drawer" && !rv.drawerOpen) throw new Stop("UNSUPPORTED", "cart drawer present but could not be opened; drawer not verified (cart page not substituted)");
    const base = page.url();
    visible = {
      surface,
      badgeDeclared: ADAPTERS[ad].declaresBadge,
      badgeCount: rv.badgeText === null ? null : Number.parseInt(rv.badgeText, 10),
      totalText: rv.totalText,
      lines: rv.lines.map((l) => {
        let variantId = null;
        if (l.href) {
          const v = new URL(l.href, base).searchParams.get("variant");
          variantId = v ? Number(v) : null;
        }
        return { variantId, title: l.title, options: l.options, quantity: l.quantity === null ? null : Number.parseInt(l.quantity, 10), priceText: l.priceText };
      })
    };
    const verdict = classify(market, spec.lines, stored, visible, { badge: spec.checks?.badge ?? ADAPTERS[ad].declaresBadge, total: totalMode(spec.checks?.total) });
    const allChecks = [...checks, ...verdict.checks];
    let status = verdict.status;
    let reason = verdict.reason;
    const selFail = checks.find((c) => c.name === "theme.variantSelection" && !c.ok);
    if (selFail && status === "PASS") {
      status = "REGRESSION";
      reason = `theme did not select the requested variant: ${selFail.detail}`;
    }
    const shot = status === "PASS" ? null : await screenshot(page, spec.id, opts);
    return { status, reason, checks: allChecks, market, stored, visible, screenshot: shot, retryable: false, rateLimited: false, retryAfterMs: null, theme };
  } catch (e) {
    const base = { checks, market, stored, visible, theme, rateLimited: false, retryAfterMs: null };
    if (passwordWall && !(e instanceof Stop)) {
      return { ...base, status: "BLOCKED", reason: "storefront is password-protected; supply its storefront password (never in URLs)", screenshot: null, retryable: false };
    }
    if (timedOut) {
      return { ...base, status: "ERROR", reason: `case timeout after ${timeoutMs} ms`, screenshot: null, retryable: true };
    }
    if (e instanceof Stop) {
      const shot = page && !page.isClosed() ? await screenshot(page, spec.id, opts) : null;
      return { ...base, status: e.status, reason: e.message, screenshot: shot, retryable: e.retryable, rateLimited: e.rateLimited, retryAfterMs: e.retryAfterMs };
    }
    if (e instanceof SafetyError) return { ...base, status: "UNSUPPORTED", reason: `refused by safety policy: ${e.message}`, screenshot: null, retryable: false };
    const msg = e.message?.split("\n")[0] ?? String(e);
    return { ...base, status: "ERROR", reason: `engine error: ${msg}${blocked.length ? ` (blocked: ${blocked.slice(0, 3).join(", ")})` : ""}`, screenshot: null, retryable: true };
  } finally {
    clearTimeout(timer);
    await context.close().catch(() => {
    });
  }
}
async function screenshot(page, id, opts) {
  if (!opts.screenshotDir) return null;
  const path = `${opts.screenshotDir}/${id}.png`;
  try {
    await page.screenshot({
      path,
      mask: [page.locator('input[type="email"], input[type="password"], input[type="tel"], input[name*="email" i], [data-redact], .customer, .header__icon--account')]
    });
    return path;
  } catch {
    return null;
  }
}
function retryWorthy(a) {
  return a.status === "ERROR" && !!a.retryable || a.status === "BLOCKED" && !!a.rateLimited;
}
function caseHost(spec) {
  return new URL(spec.lines[0].url).hostname.toLowerCase();
}
function deadlineBlocked(spec, opts, waitMs) {
  return { status: "BLOCKED", reason: `queued: store cooldown (${Math.ceil(waitMs / 1e3)} s) would start this case after the job deadline; credit released, retry later`, checks: [], market: null, stored: null, visible: null, screenshot: null, retryable: false, rateLimited: false, retryAfterMs: waitMs, theme: { schema: null, version: null, adapter: null, surface: null } };
}
async function pacedAttempt(browser2, spec, opts) {
  const timeoutMs = Math.min(spec.timeoutMs ?? MAX_TIMEOUT_MS, MAX_TIMEOUT_MS);
  const host = caseHost(spec);
  let waitedMs = 0;
  if (opts.pacer) {
    const slot = await opts.pacer.acquire(host, opts.deadlineAt);
    if (!slot) return { a: deadlineBlocked(spec, opts, opts.pacer.waitMs(host)), waitedMs: 0, startedAt: null };
    waitedMs = slot.waitedMs;
  }
  const startedAt = (/* @__PURE__ */ new Date()).toISOString();
  const a = await attempt(browser2, spec, opts, timeoutMs);
  opts.pacer?.record(host, { rateLimited: a.rateLimited, retryAfterMs: a.retryAfterMs });
  return { a, waitedMs, startedAt };
}
function toCaseResult(spec, opts, a, attempts, durationMs, pacing) {
  return {
    caseId: spec.id,
    kind: "single",
    engineVersion: opts.engineVersion,
    source: { urls: spec.lines.map((l) => sanitizeUrl(l.url)), evidenceClass: spec.evidenceClass },
    requested: { market: spec.market, lines: spec.lines.map((l) => ({ variantId: l.variantId, quantity: l.quantity })) },
    market: a.market,
    stored: a.stored,
    visible: a.visible,
    status: a.status,
    reason: a.reason,
    checks: a.checks,
    durationMs,
    attempts,
    cost: { measured: false, usd: "UNKNOWN", basis: "local runtime; not a provider invoice" },
    screenshot: a.screenshot,
    casesConsumed: 1,
    theme: a.theme,
    pacing
  };
}
async function runCase(browser2, spec, opts) {
  const t0 = Date.now();
  let r = await pacedAttempt(browser2, spec, opts);
  let attempts = 1;
  let waited = r.waitedMs;
  let anyRateLimited = r.a.rateLimited;
  let lastRetryAfter = r.a.retryAfterMs;
  const starts = r.startedAt ? [r.startedAt] : [];
  if (opts.retry !== "none" && retryWorthy(r.a)) {
    attempts = 2;
    r = await pacedAttempt(browser2, spec, opts);
    waited += r.waitedMs;
    anyRateLimited ||= r.a.rateLimited;
    lastRetryAfter = r.a.retryAfterMs ?? lastRetryAfter;
    if (r.startedAt) starts.push(r.startedAt);
  }
  const a = r.a;
  return toCaseResult(spec, opts, a, attempts, Date.now() - t0, { waitedMs: waited, rateLimited: anyRateLimited, retryAfterMs: lastRetryAfter, attemptStarts: starts });
}

// main.ts
var API = "https://marketcart-ci.pages.dev";
var FIXTURE = "marketcart-fixture.pages.dev";
var VERSION = "actor-0.2.0";
await Actor.init();
var input = await Actor.getInput() ?? {};
var mode = input.mode ?? "demo";
var executablePath = process.env.APIFY_CHROME_EXECUTABLE_PATH || void 0;
var browser = await chromium.launch({ headless: true, executablePath });
var results = [];
var summary = {};
try {
  if (mode === "demo") {
    const mk = (id, skin, sc) => ({ id, adapter: "dawn", market: { country: "IE", currency: "EUR" }, authorizedDomains: [FIXTURE], evidenceClass: "synthetic-fixture", lines: [{ url: `https://${FIXTURE}/k/${skin}/s/${sc}/products/linen-shirt?variant=4101&country=IE`, variantId: 4101, quantity: 1 }] });
    const specs = [mk("dawn16-drawer-healthy", "dawn16-drawer", "healthy"), mk("dawn16-drawer-stale", "dawn16-drawer", "stale-drawer"), mk("horizon44-drawer-healthy", "horizon44-drawer", "healthy"), mk("horizon44-drawer-stale", "horizon44-drawer", "stale-drawer")];
    for (const s of specs) {
      const r = await runCase(browser, s, { engineVersion: VERSION, allowLoopbackFixture: false, screenshotDir: null });
      results.push(r);
      await Actor.pushData({ ...r, evidenceClass: "synthetic-fixture" });
    }
    summary = { mode, note: "Synthetic fixture with planted defects; expected PASS, REGRESSION, PASS, REGRESSION." };
  } else {
    const host = String(input.storeHost ?? "").toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(host)) throw new Error("storeHost is required in store mode, e.g. your-store.myshopify.com");
    const tok = await (await fetch(`${API}/v1/free-token?host=${encodeURIComponent(host)}`)).json();
    const token = tok.meta?.match(/content="([a-f0-9]{24})"/)?.[1];
    if (!token) throw new Error("could not obtain the verification token");
    const own = await ownershipVerified(host, token, input.storefrontPassword);
    if (!own.ok) {
      summary = { mode, host, ownership: own.why, howTo: `Add ${tok.meta} inside <head> of layout/theme.liquid, then run again.` };
      await Actor.setValue("OUTPUT", summary);
      throw new Error(`ownership not verified: ${own.why}`);
    }
    const cases = (input.cases ?? []).slice(0, Math.min(20, input.maxCases ?? 5));
    if (cases.length === 0) throw new Error("cases: at least one case (product URL, variantId, quantity, market)");
    const pacer = new StorePacer();
    for (const c of cases) {
      const spec = { id: c.id, adapter: "dawn", market: c.market, lines: c.lines, authorizedDomains: [host], evidenceClass: "live-shopify", checks: c.checks };
      const r = await runCase(browser, spec, { engineVersion: VERSION, allowLoopbackFixture: false, screenshotDir: null, storefrontPasswords: input.storefrontPassword ? { [host]: input.storefrontPassword } : {}, pacer });
      results.push(r);
      await Actor.pushData(r);
    }
    summary = { mode, host };
  }
  const by = (s) => results.filter((r) => r.status === s).length;
  summary = { ...summary, engineVersion: VERSION, cases: results.length, PASS: by("PASS"), REGRESSION: by("REGRESSION"), BLOCKED: by("BLOCKED"), UNSUPPORTED: by("UNSUPPORTED"), ERROR: by("ERROR"), docs: `${API}/`, source: "https://github.com/paolomangiadev/marketcart-ci" };
  await Actor.setValue("OUTPUT", summary);
} finally {
  await browser.close();
}
await Actor.exit();
