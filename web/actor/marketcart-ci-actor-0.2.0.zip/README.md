# MarketCart CI — Shopify cart parity check

Checks that a Shopify cart shows what Shopify stored. A real browser opens the product page, adds the variant with the theme's own add-to-cart control, reads the stored cart from `/cart.js`, then reads what the shopper sees in the **cart drawer** (or the cart page when the theme has no drawer) and compares: variant, quantity, line price, the currency of the market the session actually got, the header badge and the total. Each case returns **PASS**, **REGRESSION** (with the exact mismatch), **UNSUPPORTED**, **BLOCKED** or **ERROR**.

It catches bugs a "200 OK" smoke test misses: the item is stored but the drawer still says "Your cart is empty", the badge stays at 0, the drawer shows quantity 1 for a stored 2, the wrong variant was added, or the right number appears with the wrong currency sign.

## Modes

- **demo** (default, no setup): four cases on a synthetic store with planted defects (Dawn 16 drawer and Horizon 4.4 drawer, healthy vs stale drawer). Expected: PASS, REGRESSION, PASS, REGRESSION.
- **store**: your own Shopify store. Prove you control it by adding the free MarketCart verification meta tag (get it at https://marketcart-ci.pages.dev/#free-check) to `layout/theme.liquid` `<head>`. Password-protected development stores are supported (the password is a secret input, used in memory only).

## Supported themes

Dawn family (Dawn, Refresh, Sense, Craft, Studio, Taste, Origin, Crave, Ride, Colorblock, Publisher, Spotlight, Trade) and Horizon 4.4. Live-verified so far: Dawn 16.1.1 on the cart page; Dawn drawer and Horizon are verified on version-pinned synthetic markup. Other themes return UNSUPPORTED.

## Limits

Never opens checkout or payment pages and never places orders. Cases are paced 15 seconds apart per store and honour Shopify's Retry-After; a case that stays rate-limited returns BLOCKED. No anti-bot evasion.

## Output

One dataset item per case (status, reason, every individual check, stored and visible cart) and an `OUTPUT` summary. Source code, CLI and GitHub Action (MIT): https://github.com/paolomangiadev/marketcart-ci
