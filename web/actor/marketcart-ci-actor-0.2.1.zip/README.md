# MarketCart CI — Shopify cart parity check (Dawn, Horizon)

Checks that a Shopify cart shows what Shopify stored. A real browser opens the product page, adds the variant with the theme's own add-to-cart control, reads the stored cart from `/cart.js`, then reads what the shopper sees in the **cart drawer** (or the cart page when the theme has no drawer) and compares: variant, quantity, line price, the currency of the market the session actually got, the header badge and the total.

It catches bugs a "200 OK" smoke test misses: the item is stored but the drawer still says "Your cart is empty", the badge stays at 0, the drawer shows quantity 1 for a stored 2, the wrong variant was added, or the right number appears with the wrong currency sign.

## Modes

- **demo** (default, no setup): four cases on a synthetic store with planted defects — Dawn 16 drawer and Horizon 4.4 drawer, each healthy vs stale drawer. Expected: PASS, REGRESSION, PASS, REGRESSION.
- **store**: your own Shopify store. The first run prints a `verificationTag` in the `OUTPUT` record (a meta tag tied to your Apify account and the store host). Add it to `layout/theme.liquid` inside `<head>`, save, and run again: cases only run after the tag is found on the store's home page. Password-protected development stores are supported: the storefront password is a secret input, used in memory for the run only.

## Sample input (store mode)

```json
{
  "mode": "store",
  "storeHost": "your-store.myshopify.com",
  "maxCases": 2,
  "cases": [
    { "id": "tee-s", "market": { "country": "US", "currency": "USD" },
      "lines": [{ "url": "https://your-store.myshopify.com/products/tee?variant=123", "variantId": 123, "quantity": 1 }] },
    { "id": "tee-m-x2", "market": { "country": "US", "currency": "USD" },
      "lines": [{ "url": "https://your-store.myshopify.com/products/tee?variant=124", "variantId": 124, "quantity": 2 }],
      "checks": { "total": true } }
  ]
}
```

## Sample output (one dataset item per case; demo run)

```json
{ "caseId": "dawn16-drawer-stale", "status": "REGRESSION",
  "reason": "stored 1 line(s), visible 0 line(s) in drawer; stored line Linen Shirt (Red / M, variant 4101) not visible",
  "theme": { "schema": "Dawn", "version": "16.1.1", "adapter": "dawn", "surface": "drawer" },
  "attempts": 1, "durationMs": 2310 }
```

Each item also contains every individual check, the stored cart and the visible cart. The run's `OUTPUT` record summarizes counts per status.

## Statuses

| Status | Meaning |
|---|---|
| PASS | stored == visible on every check, market verified in the session |
| REGRESSION | a real mismatch (missing line, wrong variant, quantity, amount, currency, badge or total) — the reason says which |
| UNSUPPORTED | theme without an adapter, requested market not served, unreadable price, or the store rejected the add (e.g. HTTP 422) |
| BLOCKED | Shopify rate limiting (HTTP 429) after one paced retry, a bot challenge, or a password wall without password |
| ERROR | timeout or runtime failure after one retry |

## Supported themes and limits

Dawn family (Dawn, Refresh, Sense, Craft, Studio, Taste, Origin, Crave, Ride, Colorblock, Publisher, Spotlight, Trade) and Horizon 4.4. **Live-verified so far: Dawn 16.1.1 on the cart page.** Dawn drawer and Horizon are verified on version-pinned synthetic markup; live verification is pending. Other themes return UNSUPPORTED. Cases are paced 15 seconds apart per store and honour Shopify's Retry-After. Never opens checkout or payment pages and never places orders. Up to 20 cases per run (default 5).

## Pricing

This Actor has no Actor fee. Runs use your own Apify platform usage (compute), like any Actor: free does not mean unlimited free compute. A demo run used about USD 0.001 of platform usage in our test (2 GB memory, under a minute). Budget roughly 15–30 seconds of run time per store case, because cases are paced to respect Shopify's rate limits.
